/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./LookupChoice/Components/LookupChoice.tsx":
/*!**************************************************!*\
  !*** ./LookupChoice/Components/LookupChoice.tsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LookupCombobox: () => (/* binding */ LookupCombobox)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\n\n\nvar useStyles = (0,_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.makeStyles)({\n  root: {\n    width: \"100%\"\n  }\n});\nvar LookupCombobox = props => {\n  var _a;\n  var [state, setState] = react__WEBPACK_IMPORTED_MODULE_0__.useState({\n    categories: [],\n    entityIdFieldName: \"\",\n    entityNameFieldName: \"\",\n    entityDisplayName: \"\",\n    selectedKey: props.selectedId,\n    selectedText: \"\",\n    parentRecordId: props.parentRecordId\n  });\n  var [query, setQuery] = react__WEBPACK_IMPORTED_MODULE_0__.useState(\"\");\n  var [isSearching, setIsSearching] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);\n  var availableOptions = [];\n  var styles = useStyles();\n  var currentTheme = (_a = props.context.fluentDesignLanguage) === null || _a === void 0 ? void 0 : _a.tokenTheme;\n  var myTheme = props.isDisabled ? Object.assign(Object.assign({}, currentTheme), {\n    colorCompoundBrandStroke: currentTheme === null || currentTheme === void 0 ? void 0 : currentTheme.colorNeutralStroke1,\n    colorCompoundBrandStrokeHover: currentTheme === null || currentTheme === void 0 ? void 0 : currentTheme.colorNeutralStroke1Hover,\n    colorCompoundBrandStrokePressed: currentTheme === null || currentTheme === void 0 ? void 0 : currentTheme.colorNeutralStroke1Pressed,\n    colorCompoundBrandStrokeSelected: currentTheme === null || currentTheme === void 0 ? void 0 : currentTheme.colorNeutralStroke1Selected\n  }) : currentTheme;\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    retrieveMetadata();\n  }, []);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    retrieveRecords();\n  }, [state.entityIdFieldName]);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    retrieveRecords();\n  }, [props.parentRecordId]);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    displayRecords(state.categories, props.selectedId);\n  }, [props.selectedId]);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    displayRecords(state.categories, state.selectedKey);\n  }, [state.selectedKey]);\n  var retrieveMetadata = () => {\n    props.context.utils.getEntityMetadata(props.entityName).then(metadata => {\n      setState(prevState => {\n        return Object.assign(Object.assign({}, prevState), {\n          entityIdFieldName: metadata.PrimaryIdAttribute,\n          entityNameFieldName: metadata.PrimaryNameAttribute,\n          entityDisplayName: metadata.DisplayName\n        });\n      });\n      return null;\n    }).catch(error => {\n      console.log(error);\n    });\n  };\n  var setRecords = (categories, records) => {\n    var category = categories.find(c => c.key === \"records\");\n    if (!category) {\n      categories.push({\n        title: state.entityDisplayName,\n        key: \"records\",\n        type: \"records\",\n        records: records\n      });\n    } else {\n      category.title = state.entityDisplayName;\n      category.records = records;\n    }\n  };\n  var sortRecords = records => {\n    records = records.sort((n1, n2) => {\n      if (n1.text.toLowerCase() > n2.text.toLowerCase()) {\n        return 1;\n      }\n      if (n1.text.toLowerCase() < n2.text.toLowerCase()) {\n        return -1;\n      }\n      return 0;\n    });\n  };\n  var retrieveRecords = () => {\n    var _a;\n    if (!(((_a = state.entityDisplayName) === null || _a === void 0 ? void 0 : _a.length) > 0)) {\n      return;\n    }\n    var filter = \"\";\n    if (props.viewId) {\n      filter = \"?$top=1&$select=fetchxml,returnedtypecode&$filter=savedqueryid eq \" + props.viewId;\n    } else {\n      filter = \"?$top=1&$select=fetchxml,returnedtypecode&$filter=returnedtypecode eq '\" + props.entityName + \"' and querytype eq 64\";\n    }\n    props.context.webAPI.retrieveMultipleRecords(\"savedquery\", filter).then(result => {\n      var view = result.entities[0];\n      var xml = view.fetchxml;\n      props.context.webAPI.retrieveMultipleRecords(view.returnedtypecode, \"?fetchXml=\" + xml).then(result => {\n        availableOptions = result.entities.map(r => {\n          var _a, _b;\n          var localizedEntityFieldName = \"\";\n          var mask = props.context.parameters.attributemask.raw;\n          if (mask) {\n            localizedEntityFieldName = mask.replace(\"{lcid}\", props.context.userSettings.languageId.toString());\n          }\n          return {\n            key: r[state.entityIdFieldName],\n            text: (_b = (_a = r[localizedEntityFieldName]) !== null && _a !== void 0 ? _a : r[state.entityNameFieldName]) !== null && _b !== void 0 ? _b : \"Display Name is not available\"\n          };\n        });\n        if (props.context.parameters.sortByName.raw === \"1\") {\n          sortRecords(availableOptions);\n        }\n        availableOptions.splice(0, 0, {\n          key: \"---\",\n          text: \"---\"\n        });\n        var categories = [];\n        setRecords(categories, availableOptions);\n        displayRecords(categories, props.selectedId);\n        return null;\n      }).catch(error => {\n        console.log(error.message);\n      });\n      return null;\n    }).catch(error => {\n      console.log(error.message);\n    });\n  };\n  var displayRecords = (categories, selectedKey) => {\n    var _a, _b, _c;\n    availableOptions = availableOptions.length > 0 ? availableOptions : (_b = (_a = state.categories.find(c => c.type === \"records\")) === null || _a === void 0 ? void 0 : _a.records) !== null && _b !== void 0 ? _b : [];\n    if (availableOptions.length === 0) {\n      return;\n    }\n    var selectedOption = availableOptions.find(o => o.key === selectedKey);\n    setQuery((_c = selectedOption === null || selectedOption === void 0 ? void 0 : selectedOption.text) !== null && _c !== void 0 ? _c : \"---\");\n    setState(prevState => {\n      var _a, _b;\n      return Object.assign(Object.assign({}, prevState), {\n        categories: categories,\n        selectedKey: (_a = selectedOption === null || selectedOption === void 0 ? void 0 : selectedOption.key) !== null && _a !== void 0 ? _a : \"---\",\n        selectedText: (_b = selectedOption === null || selectedOption === void 0 ? void 0 : selectedOption.text) !== null && _b !== void 0 ? _b : \"---\"\n      });\n    });\n  };\n  var updateSelectedItem = (selectedId, selectedText) => {\n    setState(prevState => {\n      var _a;\n      return Object.assign(Object.assign({}, prevState), {\n        selectedKey: (_a = selectedId === null || selectedId === void 0 ? void 0 : selectedId.replace(/[{}]/g, \"\").toLowerCase()) !== null && _a !== void 0 ? _a : \"---\",\n        selectedText: selectedText !== null && selectedText !== void 0 ? selectedText : \"---\"\n      });\n    });\n    setIsSearching(false);\n    setQuery(selectedText !== null && selectedText !== void 0 ? selectedText : \"\");\n  };\n  var handleOptionSelect = (event, data) => {\n    var _a;\n    var newValue = {\n      id: ((_a = data.optionValue) !== null && _a !== void 0 ? _a : \"\").split(\"_mru\")[0].split(\"_fav\")[0],\n      name: data.optionText,\n      entityType: props.entityName\n    };\n    props.notifyOutputChanged(newValue);\n    updateSelectedItem(newValue.id, newValue.name);\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    className: styles.root\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.FluentProvider, {\n    theme: myTheme,\n    className: styles.root\n  }, props.isDisabled ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Input, {\n    value: state.selectedText,\n    appearance: \"filled-darker\",\n    className: styles.root,\n    readOnly: props.isDisabled\n  })) : (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Combobox, Object.assign({}, props, {\n    placeholder: \"---\",\n    onChange: ev => {\n      setQuery(ev.target.value);\n      setIsSearching(true);\n    },\n    onOptionSelect: handleOptionSelect,\n    selectedOptions: [state.selectedKey],\n    value: query,\n    className: styles.root,\n    appearance: \"filled-darker\"\n  }), state.categories.length === 1 ? state.categories[0].records.filter(r => isSearching && r.text.toLowerCase().includes(query.toLowerCase()) || !isSearching).map(record => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: record.key,\n    text: record.text,\n    value: record.key,\n    className: \"{styles.root}\"\n  }, record.text))) : state.categories.map(category => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.OptionGroup, {\n    label: category.title,\n    key: category.key,\n    className: \"{styles.root}\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: category.key === \"records\" ? {\n      maxHeight: \"300px\",\n      overflowY: \"auto\",\n      overflowX: \"hidden\"\n    } : {}\n  }, category.records.filter(r => isSearching && r.text.toLowerCase().includes(query.toLowerCase()) && category.type === \"records\" || !isSearching || category.type != \"records\").map(record => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: record.key,\n    text: record.text,\n    value: record.key,\n    className: \"{styles.root}\"\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Label, null, record.text))))))))))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LookupChoice/Components/LookupChoice.tsx?\n}");

/***/ }),

/***/ "./LookupChoice/index.ts":
/*!*******************************!*\
  !*** ./LookupChoice/index.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LookupChoice: () => (/* binding */ LookupChoice)\n/* harmony export */ });\n/* harmony import */ var _Components_LookupChoice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Components/LookupChoice */ \"./LookupChoice/Components/LookupChoice.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass LookupChoice {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.entityName = context.parameters.lookupControl.getTargetEntityType();\n    this.viewId = context.parameters.lookupControl.getViewId();\n  }\n  renderControl(context) {\n    var _a;\n    var recordId = context.parameters.lookupControl.raw != null && context.parameters.lookupControl.raw.length > 0 ? (_a = context.parameters.lookupControl.raw[0].id) === null || _a === void 0 ? void 0 : _a.replace(/[{}]/g, \"\").toLowerCase() : '---';\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_Components_LookupChoice__WEBPACK_IMPORTED_MODULE_0__.LookupCombobox, {\n      context: context,\n      selectedId: recordId,\n      selectedOptions: [recordId],\n      viewId: this.viewId,\n      entityName: this.entityName,\n      isDisabled: context.mode.isControlDisabled,\n      notifyOutputChanged: this.notifyChange.bind(this),\n      parentRecordId: undefined\n    });\n  }\n  notifyChange(value) {\n    this.currentValue = value ? [value] : undefined;\n    this.notifyOutputChanged();\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    if (context.updatedProperties.includes(\"lookup\")) {\n      return this.renderControl(context);\n    }\n    return this.renderControl(context);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      lookupControl: this.currentValue\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LookupChoice/index.ts?\n}");

/***/ }),

/***/ "@fluentui/react-components":
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
/***/ ((module) => {

module.exports = FluentUIReactv940;

/***/ }),

/***/ "react":
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
/***/ ((module) => {

module.exports = Reactv16;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./LookupChoice/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MDT.Components.LookupChoice', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LookupChoice);
} else {
	var MDT = MDT || {};
	MDT.Components = MDT.Components || {};
	MDT.Components.LookupChoice = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LookupChoice;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}